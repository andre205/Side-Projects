pip install pipenv

pip install opencv-python

pip install Pillow

pip install pyaudio

pip install pyqt5

pipenv install

pipenv shell
